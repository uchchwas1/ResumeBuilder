

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Edit Education</h2>


    <form action=" <?php echo e(route('user-detail.update', $userDetail)); ?> " method='POST'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="exampleFormControlInput1">Your Full Name</label>
            <input type="text" class="form-control" name = "fullname" value="<?php echo e($userDetail->fullname); ?>">
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Enter Your Email</label>
            <input type="text" class="form-control" name = "email" value="<?php echo e($userDetail->email); ?>">
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Enter Your Phone Number</label>
            <input type="text" class="form-control" name = "phone" value="<?php echo e($userDetail->phone); ?>">
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Enter Your Full Address</label>
            <input type="text" class="form-control" name = "address" value="<?php echo e($userDetail->address); ?>">
        </div>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Summary About You</label>
            <textarea class="form-control" name = "summary" rows="4"> <?php echo e($userDetail->summary); ?> </textarea>
        </div>
        <button type="submit" class="btn btn-success">Submit</button>
 
        <!-- <input type="text" name='fullname' placeholder='Full Name' value="<?php echo e($userDetail->fullname); ?>">       
       <input type = "text" name = "email" placeholder = "email" value="<?php echo e($userDetail->email); ?>">
       <input type = "text" name = "phone" placeholder = "mobile number" value="<?php echo e($userDetail->phone); ?>">
       <input type = "text" name = "address" placeholder = "address" value="<?php echo e($userDetail->address); ?>">
       <textarea name = "summary" id ="" cols= "30" rows = "4" >
              <?php echo e($userDetail->summary); ?>

       </textarea> -->
       


    </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Git\Laravel Project\ResumeBuilder\resources\views/usr_details/edit.blade.php ENDPATH**/ ?>