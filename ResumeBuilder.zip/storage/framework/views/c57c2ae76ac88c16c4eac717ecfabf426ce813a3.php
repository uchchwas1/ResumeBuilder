
<?php $__env->startSection('content'); ?>


<h2>User Profile</h2>

    
     <div class = "card">
         <div class = "card-body">
             <h4 class = "card-title">
                 <b>User Name:</b> <?php echo e($details->fullname); ?> <br>
                 <b>User E-mail:</b> <?php echo e($details->email); ?> <br>
                 <b>User Phone:</b> <?php echo e($details->phone); ?> <br>
                 <b>User Summary:</b><p>"<?php echo e($details->summary); ?>"</P><br>
             </h4>
             <a class = "btn btn-sm btn-primary" href = " <?php echo e(route('user-detail.edit', $details)); ?> " role = "button">Edit User Data and Summary</a>
            
             <!-- <form action="<?php echo e(route('user-detail.destroy', $details)); ?>" method="POST" style="display: inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="submit" value="Delete" class="btn btn-sm btn-danger">
            </form> -->
        </div>
    </div>

 
 
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Git\Laravel Project\ResumeBuilder\resources\views/usr_details/index.blade.php ENDPATH**/ ?>