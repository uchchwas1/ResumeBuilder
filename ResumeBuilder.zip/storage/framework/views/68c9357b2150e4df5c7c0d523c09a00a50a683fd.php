

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Edit Skill Detail</h2>

    <form action="<?php echo e(route('skill.update', $skill)); ?>" method='POST'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

            <div class="form-group">
                        <label for="exampleFormControlInput1">Skill Name</label>
                        <input type="text" class="form-control" name = "name" value="<?php echo e($skill->name); ?>">
            </div>
            <div class="form-group">
                        <label for="exampleFormControlInput1">Rating Range (1 to 10)</label>
                        <input type="range" class="form-range" min="1" max="10" id="customRange2" name = "rating" value="<?php echo e($skill->rating); ?>">
            </div>
            <button type="submit" class="btn btn-success">Save</button>

        <!-- <input type="text" name='name' placeholder='Skill Name' value="<?php echo e($skill->name); ?>">


        <input type="text" name='rating' placeholder='Rating' value="<?php echo e($skill->rating); ?>">

        <input type="submit" value="Save"> -->

    </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Git\Laravel Project\ResumeBuilder\resources\views/skills/edit.blade.php ENDPATH**/ ?>