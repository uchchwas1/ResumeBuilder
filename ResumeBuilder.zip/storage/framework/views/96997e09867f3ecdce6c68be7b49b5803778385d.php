

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Edit Education</h2>


    <form action="<?php echo e(route('experience.update', $experience)); ?>" method='POST'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
 
                <div class="form-group">
                    <label for="exampleFormControlInput1">Company Name</label>
                    <input type="text" class="form-control" name = "employer" value="<?php echo e($experience->employer); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Designation</label>
                    <input type="text" class="form-control" name = "job_title" value="<?php echo e($experience->job_title); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Company Location</label>
                    <input type="text" class="form-control" name = "city" value="<?php echo e($experience->city); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Area of Experiences</label>
                    <input type="text" class="form-control" name = "state" value="<?php echo e($experience->state); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Employment Period: Joining Date</label>
                    <input type = "date" class="form-control" name = "start_date" value="<?php echo e($experience->start_date); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Employment Period: Exit Date</label>
                    <input type = "date" class="form-control" name = "end_date" value="<?php echo e($experience->end_date); ?>">
                </div>

                
                <button type="submit" class="btn btn-success">Save</button>

 
        <!-- <input type="text" name='job_title' placeholder='job name' value="<?php echo e($experience->job_title); ?>">

        <input type="text" name='employer' placeholder='employer' value="<?php echo e($experience->employer); ?>">

        <input type="text" name='city' placeholder='city' value="<?php echo e($experience->city); ?>">

        <input type="text" name='state' placeholder='state' value="<?php echo e($experience->state); ?>">

        <input type="date" name='start_date' value="<?php echo e($experience->start_date); ?>">
        <input type="date" name='end_date' value="<?php echo e($experience->end_date); ?>">

        <input type="submit" value="Save Modifications"> -->

    </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Git\Laravel Project\ResumeBuilder\resources\views/experience/edit.blade.php ENDPATH**/ ?>