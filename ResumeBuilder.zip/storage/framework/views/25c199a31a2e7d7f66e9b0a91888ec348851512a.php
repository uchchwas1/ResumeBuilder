
<h1>Your First Name: <?php echo e($firstkey); ?></h1>
<h1>Your Middle Name: <?php echo e($middlekey); ?></h1>
<h1>Your Last Name: <?php echo e($lastkey); ?></h1>
<?php /**PATH C:\Users\Uchchwas\Desktop\Laravel Project\ResumeBuilder\resources\views/InfoPage.blade.php ENDPATH**/ ?>