

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Edit Education</h2>


    <form action="<?php echo e(route('education.update', $education)); ?>" method='POST'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
        <label for="exampleFormControlInput1">Institute Name</label>
        <input type="text" class="form-control" name = "school_name" value="<?php echo e($education->school_name); ?>">
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">School Location</label>
        <input type="text" class="form-control" name = "school_location" value="<?php echo e($education->school_location); ?>">
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Exam/Degree Title</label>
        <input type="text" class="form-control" name = "degree" value="<?php echo e($education->degree); ?>">
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Concentration/ Major/Group</label>
        <input type="text" class="form-control" name = "field_of_study" value="<?php echo e($education->field_of_study); ?>">
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Joining Date</label>
           <input type = "date" class="form-control" name = "graduation_start_date" value="<?php echo e($education->graduation_start_date); ?>">
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Graduation Date</label>
           <input type = "date" class="form-control" name = "graduation_end_date" value="<?php echo e($education->graduation_end_date); ?>">
      </div>

      
      <button type="submit" class="btn btn-success">Submit</button>
 
        <!-- <input type="text" name='school_name' placeholder='school name' value="<?php echo e($education->school_name); ?>">

        <input type="text" name='school_location' placeholder='location' value="<?php echo e($education->school_location); ?>">

        <input type="text" name='degree' placeholder='degree' value="<?php echo e($education->degree); ?>">

        <input type="text" name='field_of_study' placeholder='faculty' value="<?php echo e($education->field_of_study); ?>">

        <input type="date" name='graduation_start_date' value="<?php echo e($education->graduation_start_date); ?>">
        <input type="date" name='graduation_end_date' value="<?php echo e($education->graduation_end_date); ?>">

        <input type="submit" value="Save Education"> -->

    </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Git\Laravel Project\ResumeBuilder\resources\views/education/edit.blade.php ENDPATH**/ ?>