
<?php $__env->startSection('content'); ?>

<div class="mb-2">
<h2>Skills Summary</h2>
   
    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class = "card">
         <div class = "card-body">
             <h4 class = "card-title"><?php echo e($e->name); ?> Proficiency Score: <?php echo e($e->rating); ?> </h4>
             <a class = "btn btn-sm btn-primary" href = " <?php echo e(route('skill.edit', $e)); ?> " role = "button">Edit</a>
            
             <form action="<?php echo e(route('skill.destroy', $e)); ?>" method="POST" style="display: inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="submit" value="Delete" class="btn btn-sm btn-danger">
            </form>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  
    <div class="col text-center"> 
        <a  class="btn btn-primary" href="<?php echo e(route('skill.create')); ?>" role="button">Add Skills</a>
        
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-success " data-toggle="modal" data-target="#modelId">Resume Preview</button>
            <!--Model start-->  
            <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title">Preview Resume</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                    <iframe src = "<?php echo e(route('resume.index')); ?>" width = "100%" height = "900"></iframe>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <a name="" id="" class="btn btn-primary" href="<?php echo e(route('resume.download')); ?>" role="button">Download</a>
                    </div>
                </div>
                </div>
            </div>
            
            <!--Model end--> 
        <a  class="btn btn-info" href="<?php echo e(route('resume.download')); ?>" role="button">Resume Download</a>
    </div> 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Git\Laravel Project\ResumeBuilder\resources\views/skills/index.blade.php ENDPATH**/ ?>