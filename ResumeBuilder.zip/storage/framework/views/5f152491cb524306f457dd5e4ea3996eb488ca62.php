
<?php $__env->startSection('content'); ?>

<h1>Experience Summary</h2>  
    <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class = "card">
         <div class = "card-body">
             <h4 class="card-title"> <?php echo e($e->job_title); ?>  (<?php echo e($e->start_date); ?> to <?php echo e($e->end_date); ?>) </h4>
                    <ul>
                        <li><?php echo e($e->employer); ?></li>
                        <li><?php echo e($e->city); ?></li>
                        <li><?php echo e($e->state); ?></li>
                    </ul>
        
            <a  class="btn btn-sm btn-primary" href=" <?php echo e(route('experience.edit', $e)); ?> " role="button">Edit</a>

                <form action="<?php echo e(route('experience.destroy', $e)); ?>" method="POST" style="display: inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <input type="submit" value="Delete" class="btn btn-sm btn-danger">
                </form>

            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="col text-center">   
    <a  class="btn btn-info mt-3" href="<?php echo e(route('experience.create')); ?>" role="button">Add Experiences</a>
    <a  class="btn btn-success mt-3" href="<?php echo e(route('skill.index')); ?>" role="button">Add Skills</a>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Git\Laravel Project\ResumeBuilder\resources\views/experience/index.blade.php ENDPATH**/ ?>