@extends('layouts.app')
@section('title','About Us')
@section('content')

<div class = 'container'>
    <div class = 'row'>
        <div class="col-mod-12"></div>
           <h1>About Page </h1>
        <div>
    <div>
</div>


@endsection