

<?php $__env->startSection('content'); ?>
                <ul class="navbar-nav">
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register-user')); ?>">Register</a>
                    </li>
                    <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('signout')); ?>">Logout</a>
                    </li>
                    <div class = 'container'>
                        <h2>Welcome to Resume Builder</h2>
                        <a name = "" id = "" class = "btn btn-primary" href = "<?php echo e(route('user-detail.create')); ?>" role = "button">Build Now</a>
                    </div>
                        <?php endif; ?>
                </ul>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Git\Laravel Project\ResumeBuilder\resources\views/dashboard.blade.php ENDPATH**/ ?>